# FORMA — Architecture & Design Studio
**A premium, production-ready architecture portfolio website**

---

## Folder Structure

```
forma/
├── index.html          ← Main HTML (all sections)
├── css/
│   └── style.css       ← Complete stylesheet (variables, layout, animations)
├── js/
│   └── main.js         ← All interactions (cursor, loader, filter, lightbox, slider)
├── images/             ← Add your own images here (currently uses Unsplash CDN)
└── README.md           ← This file
```

---

## Features

- **Custom animated cursor** with hover states
- **Page loader** with progress bar
- **Sticky nav** — transparent → frosted glass on scroll, hamburger on mobile
- **Hero** — full-bleed image with parallax, animated Ken Burns effect
- **Marquee ticker** with services
- **About** — editorial two-column layout with image pair
- **Projects grid** — asymmetric 12-col grid, category filter, hover effects
- **Lightbox** with image gallery, metadata, project descriptions
- **Services** — icon grid with ghost number watermarks
- **Feature strip** — full-bleed quote section
- **Testimonials** — auto-advancing slider with controls
- **Client logos** strip
- **Contact** form with simulated send state
- **Footer** with nav and social links
- **Scroll-triggered reveal** animations throughout
- **Lazy loading** for all non-hero images
- **Mobile-first responsive** (breakpoints: 1024, 768, 480px)
- **SEO meta tags** + OG tags included

---

## Deploy to GitHub Pages

### Method 1: Direct Upload (simplest)

1. Create a new GitHub repository (e.g., `forma-website`)
2. Upload all files maintaining the folder structure:
   ```
   forma/
   ├── index.html
   ├── css/style.css
   ├── js/main.js
   └── README.md
   ```
3. Go to **Settings → Pages**
4. Under **Source**, select `Deploy from a branch`
5. Choose `main` branch, `/ (root)` folder
6. Click **Save**
7. Your site will be live at: `https://yourusername.github.io/forma-website/`

### Method 2: Git CLI

```bash
# Clone or create repo
git init
git remote add origin https://github.com/yourusername/forma-website.git

# Add all files
git add .
git commit -m "Initial commit — FORMA portfolio"
git push -u origin main

# Enable Pages in GitHub repo Settings → Pages
```

### Method 3: GitHub Desktop
1. Open GitHub Desktop → File → New Repository
2. Copy all forma files into the repo folder
3. Commit and push
4. Enable Pages in repo settings

---

## Customisation Guide

### Change firm name / branding
Search and replace `FORMA` in `index.html` and update:
- `<title>` tag
- `.nav-logo` text
- `.footer-logo` text
- `.loader-wordmark` text
- Meta description

### Update projects
Edit the `PROJECTS` array at the top of `js/main.js`. Each project object:
```js
{
  name: 'Project Name',
  category: 'residential',    // residential | commercial | cultural | urban
  location: 'City, Country',
  year: '2024',
  area: '500 sqm',
  status: 'Completed',
  images: ['url1', 'url2', 'url3'],
  desc: 'Project description...',
}
```

Also update the matching `.project-card` elements in `index.html`.

### Use local images instead of Unsplash
1. Add images to the `/images/` folder
2. Replace `https://images.unsplash.com/...` URLs with `images/your-image.jpg`

### Change accent color
In `css/style.css`, update:
```css
--accent: #c8a96e;   /* warm gold — change to any hex */
```

### Add Google Analytics
Paste your GA4 script tag just before `</head>` in `index.html`.

### Make the contact form functional
Replace the form submit handler in `js/main.js` with a service like:
- **Formspree**: Change `<form>` action to `https://formspree.io/f/yourID`
- **Netlify Forms**: Add `netlify` attribute to `<form>`
- **EmailJS**: Use their SDK in the submit handler

---

## Performance Notes

- Fonts loaded via Google Fonts with `display=swap`
- Hero image uses `loading="eager"` (above fold)
- All other images use `loading="lazy"`
- CSS uses `will-change` sparingly
- Animations respect `prefers-reduced-motion`
- No external JS libraries or frameworks

---

## Browser Support

Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

---

*Designed and coded for FORMA Architecture & Design Studio.*
*Replace placeholder content with your firm's real work before publishing.*
