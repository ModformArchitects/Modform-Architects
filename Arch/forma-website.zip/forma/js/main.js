/* ════════════════════════════════════════════════════════════
   FORMA — Architecture & Design Studio
   Main JavaScript
   ════════════════════════════════════════════════════════════ */

'use strict';

/* ── Project data (for lightbox) ─────────────────────────── */
const PROJECTS = [
  {
    name: 'Meridian House',
    category: 'Residential',
    location: 'Alibaug, Maharashtra',
    year: '2023',
    area: '680 sqm',
    status: 'Completed',
    images: [
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1000&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&q=80',
    ],
    desc: 'Meridian House is a coastal retreat designed around the rhythm of the Konkan shoreline. The building\'s sculptural massing — a series of interlocking volumes — responds to solar orientation while framing views of the estuary. Raw concrete, teak, and local laterite stone form a material palette that weathers beautifully against the salt air.',
  },
  {
    name: 'Axis Tower',
    category: 'Commercial',
    location: 'BKC, Mumbai',
    year: '2022',
    area: '24,000 sqm',
    status: 'Completed',
    images: [
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1000&q=80',
      'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=600&q=80',
      'https://images.unsplash.com/photo-1555636222-cae831e670b3?w=600&q=80',
    ],
    desc: 'A 24-storey mixed-use tower in the Bandra–Kurla Complex, Axis Tower integrates workplace, retail, and public atrium within a taut glass envelope. The structural grid is expressed externally, giving the facade legibility and depth. A double-height sky garden on the 12th floor acts as a social and ecological threshold within the building.',
  },
  {
    name: 'The Archive Museum',
    category: 'Cultural',
    location: 'Pune, Maharashtra',
    year: '2022',
    area: '3,400 sqm',
    status: 'Completed',
    images: [
      'https://images.unsplash.com/photo-1555636222-cae831e670b3?w=1000&q=80',
      'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=600&q=80',
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&q=80',
    ],
    desc: 'A repository for Pune\'s industrial and cultural heritage, The Archive Museum occupies a repurposed 1930s mill building. The intervention preserves the original brick shell while inserting a new steel-and-glass core — a building within a building. Skylights flood the central atrium, casting light that shifts with the season and hour.',
  },
  {
    name: 'Kora Villa',
    category: 'Residential',
    location: 'Assagao, Goa',
    year: '2021',
    area: '420 sqm',
    status: 'Completed',
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1000&q=80',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=600&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
    ],
    desc: 'Kora Villa dissolves the boundary between interior and landscape. Set among old-growth cashew trees in north Goa, the house is arranged as a series of pavilions connected by open verandas and courtyard water channels. Lime-plastered walls, exposed bamboo structure, and local basalt floors make the building feel grown rather than built.',
  },
  {
    name: 'Dharavi Precinct',
    category: 'Urban',
    location: 'Dharavi, Mumbai',
    year: '2021',
    area: '8.2 ha masterplan',
    status: 'In Progress',
    images: [
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1000&q=80',
      'https://images.unsplash.com/photo-1555636222-cae831e670b3?w=600&q=80',
      'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=600&q=80',
    ],
    desc: 'A participatory masterplan for an 8.2-hectare block in Dharavi, developed in collaboration with local residents, traders, and the municipal corporation. The proposal retains the productive density of the existing fabric while introducing green corridors, shared infrastructure, and public amenities. Built in four phases over twelve years.',
  },
  {
    name: 'Woven Office',
    category: 'Commercial',
    location: 'Hyderabad, Telangana',
    year: '2020',
    area: '4,800 sqm',
    status: 'Completed',
    images: [
      'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=1000&q=80',
      'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=600&q=80',
      'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&q=80',
    ],
    desc: 'Woven is a campus-scale office complex for a technology company, designed around the principles of choice, community, and concentration. Rather than open-plan uniformity, the interior is a landscape of varied environments — alcoves, libraries, terraces, and collaborative halls — threaded together by a central street.',
  },
];

/* ══════════════════════════════════════════════════════════
   LOADER
   ══════════════════════════════════════════════════════════ */
(function initLoader() {
  const loader  = document.getElementById('loader');
  const fill    = document.getElementById('loaderFill');
  if (!loader) return;

  // Animate bar, then hide
  requestAnimationFrame(() => {
    fill.style.width = '100%';
  });

  setTimeout(() => {
    loader.classList.add('hidden');
    document.body.style.overflow = '';
    initReveal();   // Trigger first in-view batch
  }, 1600);

  document.body.style.overflow = 'hidden';
})();

/* ══════════════════════════════════════════════════════════
   CUSTOM CURSOR
   ══════════════════════════════════════════════════════════ */
(function initCursor() {
  const cursor    = document.getElementById('cursor');
  const cursorDot = document.getElementById('cursorDot');
  if (!cursor || !window.matchMedia('(hover: hover)').matches) return;

  let mx = 0, my = 0, cx = 0, cy = 0;

  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
    cursorDot.style.left = mx + 'px';
    cursorDot.style.top  = my + 'px';
  });

  // Smooth follow
  (function tick() {
    cx += (mx - cx) * 0.12;
    cy += (my - cy) * 0.12;
    cursor.style.left = cx + 'px';
    cursor.style.top  = cy + 'px';
    requestAnimationFrame(tick);
  })();

  // Hover states
  const hoverTargets = 'a, button, .project-card, .service-item, .client-logo, .filter-btn, .t-dot';
  document.addEventListener('mouseover', e => {
    if (e.target.closest(hoverTargets)) {
      document.body.classList.add('cursor-hover');
    }
  });
  document.addEventListener('mouseout', e => {
    if (e.target.closest(hoverTargets)) {
      document.body.classList.remove('cursor-hover');
    }
  });
})();

/* ══════════════════════════════════════════════════════════
   NAV — scroll + mobile toggle
   ══════════════════════════════════════════════════════════ */
(function initNav() {
  const nav       = document.getElementById('nav');
  const toggle    = document.getElementById('navToggle');
  const links     = document.getElementById('navLinks');
  if (!nav) return;

  // Scrolled state
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });

  // Mobile hamburger
  toggle && toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.classList.toggle('open', open);
    document.body.style.overflow = open ? 'hidden' : '';
  });

  // Close on link click
  links && links.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      links.classList.remove('open');
      toggle && toggle.classList.remove('open');
      document.body.style.overflow = '';
    });
  });
})();

/* ══════════════════════════════════════════════════════════
   SCROLL REVEAL (IntersectionObserver)
   ══════════════════════════════════════════════════════════ */
function initReveal() {
  const els = document.querySelectorAll('.reveal, .reveal-line');
  if (!els.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  els.forEach(el => observer.observe(el));
}

// Also called after loader; safe to call again
document.addEventListener('DOMContentLoaded', initReveal);

/* ══════════════════════════════════════════════════════════
   PROJECT FILTER
   ══════════════════════════════════════════════════════════ */
(function initFilter() {
  const filterWrap = document.getElementById('projectFilter');
  const grid       = document.getElementById('projectsGrid');
  if (!filterWrap || !grid) return;

  filterWrap.addEventListener('click', e => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;

    // Active state
    filterWrap.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    grid.querySelectorAll('.project-card').forEach(card => {
      const match = filter === 'all' || card.dataset.category === filter;
      card.classList.toggle('filtered-out', !match);
    });
  });
})();

/* ══════════════════════════════════════════════════════════
   LIGHTBOX
   ══════════════════════════════════════════════════════════ */
(function initLightbox() {
  const lightbox = document.getElementById('lightbox');
  const content  = document.getElementById('lightboxContent');
  const closeBtn = document.getElementById('lightboxClose');
  if (!lightbox) return;

  function open(idx) {
    const p = PROJECTS[idx];
    if (!p) return;

    content.innerHTML = `
      <div class="lb-grid">
        <div class="lb-images">
          <div class="lb-img-main">
            <img src="${p.images[0]}" alt="${p.name}" id="lbMainImg" />
          </div>
          <div class="lb-img-thumbs">
            ${p.images.map((src, i) => `
              <div class="lb-thumb" data-src="${src}" data-active="${i === 0}">
                <img src="${src}" alt="${p.name} view ${i + 1}" loading="lazy" />
              </div>
            `).join('')}
          </div>
        </div>
        <div class="lb-info">
          <p class="lb-eyebrow">${p.category}</p>
          <h2 class="lb-title">${p.name}</h2>
          <div class="lb-meta">
            <div class="lb-meta-item">
              <span class="lb-meta-label">Location</span>
              <span class="lb-meta-val">${p.location}</span>
            </div>
            <div class="lb-meta-item">
              <span class="lb-meta-label">Year</span>
              <span class="lb-meta-val">${p.year}</span>
            </div>
            <div class="lb-meta-item">
              <span class="lb-meta-label">Area</span>
              <span class="lb-meta-val">${p.area}</span>
            </div>
            <div class="lb-meta-item">
              <span class="lb-meta-label">Status</span>
              <span class="lb-meta-val">${p.status}</span>
            </div>
          </div>
          <p class="lb-desc">${p.desc}</p>
        </div>
      </div>
    `;

    // Thumbnail swap
    content.querySelectorAll('.lb-thumb').forEach(thumb => {
      thumb.addEventListener('click', () => {
        const mainImg = document.getElementById('lbMainImg');
        if (mainImg) mainImg.src = thumb.dataset.src;
        content.querySelectorAll('.lb-thumb').forEach(t => t.dataset.active = 'false');
        thumb.dataset.active = 'true';
      });
    });

    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function close() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }

  // Open on project card click
  document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('click', () => {
      const idx = parseInt(card.dataset.index, 10);
      if (!isNaN(idx)) open(idx);
    });
  });

  // Close button
  closeBtn && closeBtn.addEventListener('click', close);

  // Click outside content
  lightbox.addEventListener('click', e => {
    if (e.target === lightbox) close();
  });

  // Escape key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') close();
  });
})();

/* ══════════════════════════════════════════════════════════
   TESTIMONIALS SLIDER
   ══════════════════════════════════════════════════════════ */
(function initTestimonials() {
  const slides = document.querySelectorAll('.testimonial');
  const dots   = document.querySelectorAll('.t-dot');
  const prev   = document.getElementById('tPrev');
  const next   = document.getElementById('tNext');
  if (!slides.length) return;

  let current = 0;
  let timer;

  function goTo(idx) {
    slides[current].classList.remove('active');
    dots[current] && dots[current].classList.remove('active');
    current = (idx + slides.length) % slides.length;
    slides[current].classList.add('active');
    dots[current] && dots[current].classList.add('active');
  }

  function startAuto() {
    timer = setInterval(() => goTo(current + 1), 6000);
  }
  function stopAuto() {
    clearInterval(timer);
  }

  prev && prev.addEventListener('click', () => { stopAuto(); goTo(current - 1); startAuto(); });
  next && next.addEventListener('click', () => { stopAuto(); goTo(current + 1); startAuto(); });
  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      stopAuto();
      goTo(parseInt(dot.dataset.idx, 10));
      startAuto();
    });
  });

  startAuto();
})();

/* ══════════════════════════════════════════════════════════
   CONTACT FORM (UI only — no backend)
   ══════════════════════════════════════════════════════════ */
(function initForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const btn = form.querySelector('.form-submit');
    btn.classList.add('loading');
    btn.querySelector('span').textContent = 'Sending…';

    // Simulate send
    setTimeout(() => {
      btn.classList.remove('loading');
      btn.querySelector('span').textContent = 'Message Sent ✓';
      btn.style.background = '#4caf50';
      setTimeout(() => {
        btn.querySelector('span').textContent = 'Send Message';
        btn.style.background = '';
        form.reset();
      }, 3000);
    }, 1800);
  });
})();

/* ══════════════════════════════════════════════════════════
   LAZY IMAGE LOAD (native + fallback)
   ══════════════════════════════════════════════════════════ */
(function initLazyImages() {
  // Native loading="lazy" handles most cases.
  // Below handles any remaining deferred images via IO.
  const imgs = document.querySelectorAll('img[loading="lazy"]');
  if (!('IntersectionObserver' in window)) return;

  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
        }
        obs.unobserve(img);
      }
    });
  }, { rootMargin: '200px' });

  imgs.forEach(img => obs.observe(img));
})();

/* ══════════════════════════════════════════════════════════
   PROJECT CARD — stagger index for CSS animation delay
   ══════════════════════════════════════════════════════════ */
(function staggerCards() {
  document.querySelectorAll('.project-card').forEach((card, i) => {
    card.style.setProperty('--i', i);
  });
})();

/* ══════════════════════════════════════════════════════════
   HERO — hero content reveal on load
   ══════════════════════════════════════════════════════════ */
(function heroReveal() {
  // Kick off reveal lines after a short delay post-load
  setTimeout(() => {
    document.querySelectorAll('.reveal-line').forEach((el, i) => {
      setTimeout(() => el.classList.add('in-view'), i * 120);
    });
  }, 1700); // After loader
})();

/* ══════════════════════════════════════════════════════════
   SMOOTH SCROLL — native with JS override for offset
   ══════════════════════════════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h'));
    const top = target.getBoundingClientRect().top + window.scrollY - navH;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* ══════════════════════════════════════════════════════════
   PARALLAX — hero image subtle scroll
   ══════════════════════════════════════════════════════════ */
(function initParallax() {
  const heroImg = document.querySelector('.hero-img');
  if (!heroImg || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    if (scrolled < window.innerHeight) {
      heroImg.style.transform = `scale(1.06) translateY(${scrolled * 0.15}px)`;
    }
  }, { passive: true });
})();
